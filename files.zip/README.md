# The Table — mail server

Minimal Express backend that sends real email (via Resend) and receives
real email (via Resend's inbound webhook), with the same artificial
delay/loss-chance layer the frontend mock used.

## Setup

1. `npm install`
2. Sign up at resend.com, verify a domain (they give you exact DNS
   records — SPF/DKIM for sending, MX for receiving). This can take a
   few hours to propagate, so do it first.
3. `cp .env.example .env` and fill in `RESEND_API_KEY` and
   `FROM_ADDRESS` (must be on the domain you verified).
4. `npm start` — runs on port 3000 by default.
5. Expose it publicly for the inbound webhook:
   - Deployed: Render/Railway/Fly.io, then use that public URL.
   - Local demo: `ngrok http 3000`, use the ngrok URL.
6. In Resend's dashboard, set the inbound webhook URL to
   `https://<your-public-url>/webhook/inbound`.

## Endpoints

- `POST /api/letters` `{ to, subject, body }` — queues a letter, sends
  for real after a simulated delay, may randomly report "lost"
- `GET /api/letters/:id/status` — poll delivery status
- `GET /api/letters/incoming?since=<timestamp>` — poll for new mail
- `POST /api/letters/:id/read` — mark read
- `DELETE /api/letters/:id` — shred / delete
- `POST /webhook/inbound` — Resend posts here when someone emails you

## Wiring into the frontend

Replace `MockPostOffice` in the HTML with real `fetch()` calls:

```js
// sending
async function sendLetter({ to, subject, body }) {
  const res = await fetch("https://your-server/api/letters", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ to, subject, body }),
  });
  return res.json(); // { id, status: "pending" }
}

// polling status after sending
async function pollStatus(id) {
  const res = await fetch(`https://your-server/api/letters/${id}/status`);
  return res.json(); // { id, status }
}

// polling for incoming mail — call this every few seconds
let lastSeen = Date.now();
async function pollIncoming() {
  const res = await fetch(`https://your-server/api/letters/incoming?since=${lastSeen}`);
  const letters = await res.json();
  if (letters.length) lastSeen = letters[letters.length - 1].createdAt;
  return letters;
}
```

Swap the `settle()` promise-based flow in `sendLetterToServer()` for a
`setInterval` that calls `pollStatus(id)` every second or two until it's
no longer "pending", and swap `MockPostOffice.startIncomingFeed()` for
`setInterval(pollIncoming, 4000)`.

## Notes for the demo

- If DNS/inbound setup is flaky on hackathon wifi, keep inbound mocked
  and only make outbound real — you can still email a judge live, which
  is usually the more convincing demo moment anyway.
- The `letters.json` file is your whole database. Fine for a demo,
  delete it to reset state between test runs.
