// server.js
//
// Minimal backend for "The Table" — a slow, unreliable mail table.
// Two real email paths:
//   OUTBOUND: POST /api/letters  -> Resend send API
//   INBOUND:  POST /webhook/inbound  <- Resend's inbound parse webhook
// Everything else is just a JSON file acting as a database, and a
// polling endpoint the frontend hits every few seconds.
//
// Env vars needed (put these in a .env or your host's env settings):
//   RESEND_API_KEY   - from resend.com dashboard
//   FROM_ADDRESS      - e.g. "table@mail.yourdomain.com" (must be on a verified domain)
//   PORT              - optional, defaults to 3000

import "dotenv/config";
import express from "express";
import cors from "cors";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { nanoid } from "nanoid";
import { Resend } from "resend";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.join(__dirname, "letters.json");

const resend = new Resend(process.env.RESEND_API_KEY);
const FROM_ADDRESS = process.env.FROM_ADDRESS || "table@example.com";

const app = express();
app.use(cors());
// Resend's inbound webhook posts JSON — keep the raw body limit generous
app.use(express.json({ limit: "5mb" }));

// ---------- tiny JSON "database" ----------
// Good enough for a hackathon. Swap for SQLite/Postgres if you have time.

function loadDB() {
  if (!fs.existsSync(DB_PATH)) fs.writeFileSync(DB_PATH, "[]");
  return JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
}
function saveDB(letters) {
  fs.writeFileSync(DB_PATH, JSON.stringify(letters, null, 2));
}

// letter shape:
// {
//   id, direction: "in" | "out",
//   from, to, subject, body,
//   status: "pending" | "sent" | "delivered" | "lost" | "read",
//   createdAt, deliverAt
// }

// ---------- "fight the user" delay / loss config ----------
// Same idea as the mock: different recipients get different
// artificial delay + loss chance before we actually call the
// send API. This is the deliberate friction layer.

const RECIPIENT_PROFILES = {
  local:    { label: "next street over", delayMs: 4000,  lossChance: 0.03 },
  city:     { label: "across town",      delayMs: 9000,  lossChance: 0.10 },
  region:   { label: "the next county",  delayMs: 14000, lossChance: 0.18 },
  overseas: { label: "overseas",         delayMs: 22000, lossChance: 0.32 },
};

function profileFor(toAddress) {
  // crude demo heuristic — swap for real logic (distance, TLD, whatever fits the theme)
  if (toAddress.endsWith(".local.test")) return RECIPIENT_PROFILES.local;
  return RECIPIENT_PROFILES.city;
}

// ---------- OUTBOUND: send a letter for real ----------

app.post("/api/letters", async (req, res) => {
  const { to, subject, body } = req.body;
  if (!to || !body) {
    return res.status(400).json({ error: "to and body are required" });
  }

  const profile = profileFor(to);
  const letters = loadDB();
  const letter = {
    id: nanoid(10),
    direction: "out",
    from: FROM_ADDRESS,
    to,
    subject: subject || "(no subject)",
    body,
    status: "pending",
    createdAt: Date.now(),
    deliverAt: Date.now() + profile.delayMs,
  };
  letters.push(letter);
  saveDB(letters);

  // respond immediately — the actual send happens later, async,
  // so the frontend can show "waiting for the pigeon..."
  res.json({ id: letter.id, status: "pending" });

  // simulate the slow, unreliable post before actually sending
  setTimeout(async () => {
    const all = loadDB();
    const l = all.find((x) => x.id === letter.id);
    if (!l) return;

    const lost = Math.random() < profile.lossChance;
    if (lost) {
      l.status = "lost";
      saveDB(all);
      return;
    }

    try {
      await resend.emails.send({
        from: FROM_ADDRESS,
        to: l.to,
        subject: l.subject,
        text: l.body,
      });
      l.status = "delivered";
    } catch (err) {
      console.error("send failed:", err);
      l.status = "lost"; // real failure also just reads as "lost" to the user
    }
    saveDB(all);
  }, profile.delayMs);
});

// ---------- Poll status of a sent letter ----------

app.get("/api/letters/:id/status", (req, res) => {
  const letters = loadDB();
  const letter = letters.find((l) => l.id === req.params.id);
  if (!letter) return res.status(404).json({ error: "not found" });
  res.json({ id: letter.id, status: letter.status });
});

// ---------- Poll for new incoming mail ----------
// Frontend calls this every few seconds with the timestamp it last saw.

app.get("/api/letters/incoming", (req, res) => {
  const since = Number(req.query.since || 0);
  const letters = loadDB();
  const incoming = letters
    .filter((l) => l.direction === "in" && l.createdAt > since)
    .sort((a, b) => a.createdAt - b.createdAt);
  res.json(incoming);
});

// ---------- Mark read / shred ----------

app.post("/api/letters/:id/read", (req, res) => {
  const letters = loadDB();
  const letter = letters.find((l) => l.id === req.params.id);
  if (!letter) return res.status(404).json({ error: "not found" });
  letter.status = "read";
  saveDB(letters);
  res.json({ ok: true });
});

app.delete("/api/letters/:id", (req, res) => {
  const letters = loadDB();
  const next = letters.filter((l) => l.id !== req.params.id);
  saveDB(next);
  res.json({ ok: true });
});

// ---------- INBOUND: Resend's inbound parse webhook ----------
// Configure this URL (https://yourhost.com/webhook/inbound) in Resend's
// dashboard once you've set up your domain's MX records for inbound.
// Payload shape may vary slightly by provider — log req.body once and
// adjust field names below to match exactly what you receive.

app.post("/webhook/inbound", (req, res) => {
  const payload = req.body;

  // Resend inbound payloads generally look like:
  // { from: "sender@example.com", to: ["table@mail.yourdomain.com"],
  //   subject: "...", text: "...", html: "..." }
  const letters = loadDB();
  const letter = {
    id: nanoid(10),
    direction: "in",
    from: payload.from || "unknown",
    to: FROM_ADDRESS,
    subject: payload.subject || "(no subject)",
    body: payload.text || stripHtml(payload.html) || "(empty letter)",
    status: "unread",
    createdAt: Date.now(),
  };
  letters.push(letter);
  saveDB(letters);

  // Always 200 quickly — providers retry on non-2xx and you don't
  // want a retry storm during a demo.
  res.sendStatus(200);
});

function stripHtml(html) {
  if (!html) return "";
  return html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
}

// ---------- health check ----------
app.get("/", (_req, res) => res.send("the table — mail server is up"));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`the table server listening on :${PORT}`);
  console.log(`inbound webhook: POST http://localhost:${PORT}/webhook/inbound`);
});
